% Question 2

% find the dot product and cross product of two vectors
% a=3i+4j+5k
% b=7i+8j+9k


% soln
% for finding the dot product we simply use dot function
a=[3 4 5]
b=[7 8 9]
disp('dot product is')
dot(a,b)
% a*b'  it is another way to solve dot product of two vectors
disp('cross product is')
cross(a,b)
