% Load the dataset
data = readtable('predict_students_dropout&academic_success.csv', 'VariableNamingRule', 'preserve');

% Identify numeric columns
numericColumns = varfun(@isnumeric, data, 'OutputFormat', 'uniform');

% Select only numeric columns for processing
X = data(:, numericColumns);
X = table2array(X);  % Convert the numeric columns to an array

% Z-Score Scaling (Standardization)
X_scaled = zscore(X);

% Display the scaled data
disp('Scaled Data:');
disp(X_scaled);

% Calculate the correlation matrix
correlation_matrix = corr(X_scaled);

% Set a correlation threshold
correlation_threshold = 0.6;  % Adjust this value as needed

% Find pairs of features with high correlation
[rows, cols] = find(triu(correlation_matrix, 1) > correlation_threshold);

% Remove duplicate indices
to_remove = unique(cols);  % Keep one feature from each correlated pair

% Select the remaining features
X_filtered = X_scaled(:, setdiff(1:size(X_scaled, 2), to_remove));

% Display results
fprintf("Initial Number of Features: %d\n", size(X_scaled, 2));
fprintf("Number of Features after Correlation-Based Selection: %d\n", size(X_filtered, 2));
